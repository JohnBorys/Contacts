//
//  ContactUser.swift
//  Contacts
//
//  Created by eOne Bilch Enko on 19.06.18.
//  Copyright © 2018 eOne Bilch Enko. All rights reserved.
//

import UIKit

class ContactUser {
    var name: String = ""
    var lastName: String = ""
    var phoneNumber: String = ""
    var userImage: UIImage? = UIImage(named: "user")!
    var relationshipType: RelationshipType? = RelationshipType.general
    
    init(name: String, lastName: String, phoneNumber: String) {
        self.name =  name
        self.lastName = lastName
        self.phoneNumber = "+" + phoneNumber
    }
}
